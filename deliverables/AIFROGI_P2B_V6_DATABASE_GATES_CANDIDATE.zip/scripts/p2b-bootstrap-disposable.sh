#!/bin/sh
set -eu
: "${DATABASE_URL:?DATABASE_URL must target an empty disposable database}"
case "$DATABASE_URL" in *p2b_rehearsal*) ;; *) echo 'refusing non-rehearsal database' >&2; exit 64;; esac
root_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$root_dir/prisma/p2b-baseline/runtime-roles.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -1 -f "$root_dir/prisma/p2b-baseline/baseline.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -1 -f "$root_dir/prisma/migrations/20260929090000_p2a_v6_canonical_authority/migration.sql"
