import { withCanonicalRole, type CanonicalIdentity } from "./16-PROPOSED-DB-CONTEXT";

type ProviderResult = { accepted: boolean; providerDeliveryId?: string; detail?: unknown };
type Send = (validatedManifest: unknown, signal: AbortSignal) => Promise<ProviderResult>;

// This is the sole factual delivery boundary. Routes may create an answer audit
// but cannot receive factual payload bytes; only this service loads and sends
// them. The policy row stays SHARE-locked while the provider call occurs, so
// revoke_source's policy UPDATE serializes before or after—not through—the send.
export async function deliverCanonicalAnswer(args:{
  identity: CanonicalIdentity;
  answerAuditId: string;
  deliveryKey: string;
  send: Send;
  timeoutMs: number;
}) {
  return withCanonicalRole("aifrogi_web",args.identity,async tx => {
    await tx.$queryRaw`SELECT "eligibilityGeneration" FROM "PropertyIntelligencePolicy" WHERE "propertyId"=${args.identity.propertyId} FOR SHARE`;
    const audit=await tx.$queryRaw<Array<{selectedManifest:unknown}>>`SELECT "selectedManifest" FROM "KnowledgeAnswerAudit" WHERE "propertyId"=${args.identity.propertyId} AND id=${args.answerAuditId} FOR SHARE`;
    if (!audit[0]) throw new Error("ANSWER_AUDIT_NOT_FOUND");
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),args.timeoutMs);
    try {
      const result=await args.send(audit[0].selectedManifest,controller.signal);
      const state=result.accepted ? "DELIVERED" : "FAILED";
      await tx.$executeRaw`SELECT aifrogi_security.record_answer_outcome(${args.identity.propertyId},${args.answerAuditId},${args.deliveryKey},${state}::"AnswerDeliveryState",${JSON.stringify(result)}::jsonb)`;
      return result;
    } catch (error) {
      // Timeout/network ambiguity is FAILED with `deliveryUncertain`; it is
      // never reported as delivered and requires provider-id reconciliation.
      const detail=JSON.stringify({deliveryUncertain:true,error:error instanceof Error?error.message:"unknown"});
      await tx.$executeRaw`SELECT aifrogi_security.record_answer_outcome(${args.identity.propertyId},${args.answerAuditId},${args.deliveryKey},'FAILED'::"AnswerDeliveryState",${detail}::jsonb)`;
      throw error;
    } finally { clearTimeout(timer); }
  });
}

// CI/release gate: factual route and channel-adapter modules may import this
// function, but direct provider SDK/network clients and selectedManifest access
// are forbidden outside this module.
