import assert from "node:assert/strict";
import {Pool} from "pg";
import {initializeCanonicalRoleClients} from "../lib/canonical-db-context";
import {CanonicalDeliveryUncertainError,deliverCanonicalAnswer} from "../lib/canonical-answer-delivery";

async function main(){
 const databaseUrl=process.env.DATABASE_URL!;
 const roleUrl=databaseUrl.replace("postgres@","aifrogi_web@");
 initializeCanonicalRoleClients({
  ...process.env,
  AIFROGI_WEB_DATABASE_URL:roleUrl,
  AIFROGI_PUBLIC_DATABASE_URL:databaseUrl.replace("postgres@","aifrogi_public@"),
  AIFROGI_WORKER_DATABASE_URL:databaseUrl.replace("postgres@","aifrogi_worker@"),
  AIFROGI_PUBLISHER_DATABASE_URL:databaseUrl.replace("postgres@","aifrogi_publisher@")
 });
 const owner=new Pool({connectionString:databaseUrl});
 const identity={organizationId:"delivery-org",propertyId:"delivery-property",principal:"public-bot:delivery-property",purpose:"PUBLIC_GUEST",guestSessionHash:"delivery-session"};
 const base={identity,conversationId:"delivery-conversation",sessionHash:"delivery-session",expiresAt:new Date(Date.now()+3_600_000),entryIds:["delivery-entry"],timeoutMs:25};

 async function outcome(auditId:string,key:string){
  const result=await owner.query('SELECT state,detail FROM "KnowledgeAnswerOutcome" WHERE "answerAuditId"=$1 AND "deliveryKey"=$2',[auditId,key]);
  return result.rows;
 }

let timeoutAudit="";
try {
  await deliverCanonicalAnswer({...base,deliveryKey:"timeout-key",send:async(_manifest,signal)=>new Promise((_resolve,reject)=>signal.addEventListener("abort",()=>reject(new Error("ABORTED")),{once:true}))});
  assert.fail("timeout unexpectedly succeeded");
} catch(error) {
  if(!(error instanceof CanonicalDeliveryUncertainError)) console.error("Unexpected timeout-path error",error);
  assert.ok(error instanceof CanonicalDeliveryUncertainError);
  timeoutAudit=error.answerAuditId;
}
assert.equal((await owner.query('SELECT count(*)::int n FROM "KnowledgeAnswerAudit" WHERE id=$1',[timeoutAudit])).rows[0].n,1);
const timeoutOutcome=await outcome(timeoutAudit,"timeout-key");
assert.equal(timeoutOutcome.length,1);
assert.equal(timeoutOutcome[0].state,"FAILED");
assert.equal(timeoutOutcome[0].detail.deliveryUncertain,true);
console.log("PASS provider timeout keeps pending audit and durable uncertain FAILED outcome");

let commitAudit="";
try {
  await deliverCanonicalAnswer({...base,deliveryKey:"commit-key",send:async()=>({accepted:true,providerDeliveryId:"force-commit-failure"})});
  assert.fail("forced commit failure unexpectedly succeeded");
} catch(error) {
  assert.ok(error instanceof CanonicalDeliveryUncertainError);
  commitAudit=error.answerAuditId;
}
const commitOutcome=await outcome(commitAudit,"commit-key");
assert.equal(commitOutcome.length,1);
assert.equal(commitOutcome[0].state,"FAILED");
assert.equal(commitOutcome[0].detail.providerAccepted,true);
console.log("PASS provider acceptance plus commit failure records durable uncertain FAILED outcome");

const client=new Pool({connectionString:roleUrl});
await client.query("BEGIN");
await client.query("SELECT set_config('app.organization_id',$1,true)",[identity.organizationId]);
await client.query("SELECT set_config('app.property_id',$1,true)",[identity.propertyId]);
await client.query("SELECT set_config('app.security_actor',$1,true)",[identity.principal]);
await client.query("SELECT set_config('app.system_purpose',$1,true)",[identity.purpose]);
await client.query("SELECT set_config('app.guest_session_hash',$1,true)",[identity.guestSessionHash]);
await client.query("SELECT aifrogi_security.record_answer_outcome($1,$2,$3,'FAILED',$4::jsonb)",[identity.propertyId,timeoutAudit,"duplicate-key",JSON.stringify({attempt:1})]);
await client.query("SELECT aifrogi_security.record_answer_outcome($1,$2,$3,'FAILED',$4::jsonb)",[identity.propertyId,timeoutAudit,"duplicate-key",JSON.stringify({attempt:2})]);
await client.query("COMMIT");
assert.equal((await outcome(timeoutAudit,"duplicate-key")).length,1);
console.log("PASS duplicate delivery key is idempotent and produces one immutable outcome");

 await client.end();
 await owner.end();
}

main().catch(error=>{console.error(error);process.exitCode=1;});
