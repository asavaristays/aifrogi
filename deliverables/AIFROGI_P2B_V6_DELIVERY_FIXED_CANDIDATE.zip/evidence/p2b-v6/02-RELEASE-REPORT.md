# AiFrogi P2-B v6 release-candidate report

Date: 2026-09-29. Checkout base: `99fb911ab008d92d91bf6f66c9f9cb5033f4e657`.
Original review ZIP SHA-256: `ddd88206dd4486313d9170c3ef7f14f3002dc62c4965ea0d2fedff83220e97ec`.
Environment: isolated local checkout and disposable PostgreSQL on `127.0.0.1:55432`.
No production database, service, edge, tenant, or customer record was contacted.

## Release status

**IN PROGRESS — PRODUCTION HELD.** The database bootstrap, rollback, restore,
role boundary, source-parser, startup admission, TypeScript and Webpack build
gates below pass. Full canonical claim/publication/race behavior through the
real HTTP edge is not yet complete, so this candidate is not deployable.

## Saved migration inputs

| Artifact | SHA-256 |
| --- | --- |
| Corrected Part 3 | `72b44ff9d7bac837718364d0a12c4ce2150085cd20bbc8815444e0bd2f385e48` |
| Corrected Part 15 | `5194883c52de302498f0fde85dd0103174ae53fb7439c54d6200508a899a67b7` |
| Corrected Part 5 | `e909cf4ee505b251de7443969237df0677350cf03aefdcc49159ea3cc5071e53` |
| Baseline SQL | `a149e4008efae6e39012183f6c3ca41978a0458080b74317c62752fb4c028e58` |
| Runtime roles SQL | `857b511a0ab12189ba5eee5789e123ab273b92900550b44941a92e64cf97cee1` |
| Combined v6 migration | `1e3ec3ceef2b922090fe1a98ae24a1e37675527a7760ff9d64bdf8721be0ec80` |
| Post-bootstrap catalog export | `348d022626c15a12623fa80bef959adb84665fb3ffa91f556beccff36b4decac` |

The exact original-to-corrected diffs are `part-03-corrections.diff`,
`part-15-corrections.diff`, and `part-05-corrections.diff` in this directory.

## Commands and observed results

1. Historical migrations: `DATABASE_URL=... npx prisma migrate deploy` on an
   empty disposable database — **FAIL (release blocker)**. Migration
   `20260829000000_channel_independent_foundation` references `Property` before
   that table exists. `prisma db push` was used only in the first rehearsal and
   is not the release procedure.
2. Clean baseline: `DATABASE_URL=... sh scripts/p2b-bootstrap-disposable.sh`
   — **PASS** on `bootstrap_p2b_rehearsal2`.
3. Backfill dry run and commit run using corrected Part 5 — **PASS**. Dry run
   rolled back with parity; commit mapped one legacy entry and quarantined the
   unmatched retained document as `NO_EXACT_AUTHORIZED_SOURCE`.
4. Forced rollback: baseline followed by
   `psql ... -f tests/p2b/force-migration-rollback.sql` — expected division by
   zero; `to_regclass('public."KnowledgeSource"') IS NULL` — **PASS**.
5. Restore: `pg_dump -Fc`, `createdb`, `pg_restore` — **PASS**. Normalized
   schema hashes before/after restore both
   `854a7497730f18fc7ac5dbd56d6beafbdcfdea08afeb901d6b85f45379aa821e`.
   Dump SHA-256:
   `aadefd7297a1c5dad7f4901dc3152f8a0fa92db30b62d803352dda0a0339f2de`.
6. `DATABASE_URL=... sh scripts/verify-p2b-role-boundaries.sh` — **PASS 7/7**:
   authorized session, direct-write denial, cross-property denial, forged
   principal denial, reparent denial, answer append-only, handover append-only.
7. `npm run verify:p2b:app` — **PASS 3/3** for exact build admission and
   fail-closed legacy/contract/release-ID checks.
8. Focused form, optional website, spreadsheet, PDF and website-failure suite
   via Node test runner — **PASS 38/38**.
9. `npm run typecheck` — **PASS**.
10. `npx next build --webpack` — **PASS**, 97 routes. The default Turbopack
    attempt was stopped after it made no progress; the supported Webpack build
    completed successfully.
11. `DATABASE_URL=... npm run verify:p2b:delivery` on a newly bootstrapped
    database — **PASS 3/3**. Provider timeout retained the committed pending
    audit and appended a durable `FAILED` outcome with
    `deliveryUncertain=true`; provider acceptance followed by a forced deferred
    commit failure appended `FAILED` with `providerAccepted=true`; two outcome
    calls with one delivery key produced exactly one immutable row.

## Application boundary integrated

`instrumentation.ts` now enforces exact contract/build admission at startup and
initializes separate Prisma clients for the four login roles. The website bot
factual branch fails closed when canonical mode is required, requires canonical
entry IDs, creates a caller-bound guest session only through a SECURITY DEFINER
routine, records the exact eligible publication manifest, holds the property
eligibility row across delivery acceptance, and records an append-only outcome.
Legacy fact fallback is forbidden in canonical mode. Non-factual handover and
safety responses do not assert canonical evidence.

## V5 finding decisions and behavioral trace

| Finding | Decision / enforcement | Current evidence |
| --- | --- | --- |
| V5-1 consent trigger field | Closed in corrected trigger; exact source identity comparison | SQL apply PASS; mismatched-consent adversarial case **NOT RUN** |
| V5-2 full claim manifest/evidence | Complete value, answer, qualifiers, components and bindings are sealed under locks | SQL apply PASS; full seal behavioral fixture **NOT RUN** |
| V5-3 exact publication authorization | Authorization scope hash must equal computed publication manifest | SQL apply PASS; exact/near-miss behavioral fixture **NOT RUN** |
| V5-4 sealed-row reassignment | Composite FKs plus sealed evidence/membership triggers | Catalog PASS; concurrent reparent race **NOT RUN** |
| V5-5 role context | Exact `session_user`, property, principal and purpose grant | PostgreSQL role suite PASS |
| V5-6 file backfill | Deterministic inventory, parity checks, quarantine for unverified bytes/authority | Dry-run and commit rehearsal PASS |
| V5-7 old-build admission | Startup contract/build equality plus signed edge admission design | Startup false-ID/old-contract PASS; real signed nginx edge **NOT RUN** |
| V5-8 delivery checks | Pending audit commits before provider I/O; eligibility is locked through a narrow SECURITY DEFINER manifest routine; failure is persisted in a separate transaction | PostgreSQL timeout, accepted-send/commit-failure and duplicate-key tests PASS; complete HTTP route journey **NOT RUN** |
| V5-9 restore compatibility | Explicit baseline + migration and exact normalized schema restore | Disposable restore PASS; restored real app with factual edge closed **NOT RUN** |

## Remaining release blockers

- Full claim seal, exact publication approval, pointer CAS, source revocation,
  job lease/fence/finalization, and answer-publication behavioral fixtures.
- Concurrent membership/sealing and revocation/delivery race tests.
- End-to-end HTTP trial journeys backed by the canonical PostgreSQL roles. The
  parser/lifecycle units passed, but complete route journeys are **NOT RUN**.
- Signed deployment-admission script against a real nginx staging edge and the
  compatible-build/old-build restore matrix are **NOT RUN**.
- Production backup/restore, rollout, monitoring and real-route checks are
  **NOT RUN** and require separate production approval.

All migration, deployment, tenant, publication, purge, automatic
`TRIAL_VERIFIED`, and production gates remain held.

## Execution-environment blocker

The isolated host has no `nginx` executable and no staging remote or
root-owned edge configuration. Therefore the required real staging edge test
cannot be performed from this checkout. A local mock would not satisfy the
stated acceptance rule. Staging endpoint/host access and its release-signing
public key are required before that gate can move from **NOT RUN**.
