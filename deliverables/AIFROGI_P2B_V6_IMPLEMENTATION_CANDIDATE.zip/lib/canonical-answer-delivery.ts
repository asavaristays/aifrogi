import { withCanonicalRole, type CanonicalIdentity } from "@/lib/canonical-db-context";

type ProviderResult={accepted:boolean;providerDeliveryId?:string;detail?:unknown};
export async function deliverCanonicalAnswer(args:{identity:CanonicalIdentity;conversationId:string;sessionHash:string;expiresAt:Date;entryIds:string[];deliveryKey:string;timeoutMs:number;send:(manifest:unknown,signal:AbortSignal)=>Promise<ProviderResult>}) {
 return withCanonicalRole("aifrogi_web",args.identity,async tx => {
  await tx.$executeRaw`SELECT aifrogi_security.ensure_guest_session(${args.identity.propertyId},${args.conversationId},${args.sessionHash},${args.expiresAt},${args.identity.principal})`;
  const pending=await tx.$queryRaw<Array<{answer_audit_id:string}>>`SELECT aifrogi_security.record_answer_pending(${args.identity.propertyId},${args.conversationId},${args.sessionHash},${args.entryIds}::text[]) AS answer_audit_id`;
  const answerAuditId=pending[0]?.answer_audit_id;
  if(!answerAuditId) throw new Error("ANSWER_AUDIT_NOT_CREATED");
  await tx.$queryRaw`SELECT "eligibilityGeneration" FROM "PropertyIntelligencePolicy" WHERE "propertyId"=${args.identity.propertyId} FOR SHARE`;
  const rows=await tx.$queryRaw<Array<{selectedManifest:unknown}>>`SELECT "selectedManifest" FROM "KnowledgeAnswerAudit" WHERE "propertyId"=${args.identity.propertyId} AND id=${answerAuditId} FOR SHARE`;
  if(!rows[0]) throw new Error("ANSWER_AUDIT_NOT_FOUND");
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),args.timeoutMs);
  try {
   const result=await args.send(rows[0].selectedManifest,controller.signal);
   await tx.$executeRaw`SELECT aifrogi_security.record_answer_outcome(${args.identity.propertyId},${answerAuditId},${args.deliveryKey},${result.accepted?"DELIVERED":"FAILED"}::"AnswerDeliveryState",${JSON.stringify(result)}::jsonb)`;
   return {...result,answerAuditId};
  } catch(error) {
   const detail=JSON.stringify({deliveryUncertain:true,error:error instanceof Error?error.message:"unknown"});
   await tx.$executeRaw`SELECT aifrogi_security.record_answer_outcome(${args.identity.propertyId},${answerAuditId},${args.deliveryKey},'FAILED'::"AnswerDeliveryState",${detail}::jsonb)`;
   throw error;
  } finally { clearTimeout(timer); }
 });
}
