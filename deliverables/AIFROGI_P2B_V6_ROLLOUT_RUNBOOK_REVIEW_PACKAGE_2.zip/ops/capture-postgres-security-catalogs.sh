#!/usr/bin/env bash
set -euo pipefail
: "${AIFROGI_CATALOG_DATABASE_URL:?Explicit catalog target is required}"
: "${AIFROGI_CATALOG_EXPECTED_DATABASE:?Expected database name is required}"
: "${AIFROGI_CATALOG_EXPECTED_SERVER_ADDR:?Expected inet_server_addr is required (or LOCAL_SOCKET)}"
: "${AIFROGI_CATALOG_EXPECTED_ROLE:?Expected catalog session_user is required}"
: "${1:?Pass a new output directory path}"
output_dir="$1"
[[ ! -e "$output_dir" ]] || { echo "Refusing existing catalog output path" >&2; exit 64; }
actual_identity="$(psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 -At -F $'\t' -c "SELECT current_database(),COALESCE(inet_server_addr()::text,'LOCAL_SOCKET'),session_user")"
IFS=$'\t' read -r actual_database actual_server_addr actual_role <<<"$actual_identity"
[[ "$actual_database" == "$AIFROGI_CATALOG_EXPECTED_DATABASE" ]] || { echo "Refusing catalog capture: database mismatch" >&2; exit 65; }
[[ "$actual_server_addr" == "$AIFROGI_CATALOG_EXPECTED_SERVER_ADDR" ]] || { echo "Refusing catalog capture: server mismatch" >&2; exit 66; }
[[ "$actual_role" == "$AIFROGI_CATALOG_EXPECTED_ROLE" ]] || { echo "Refusing catalog capture: role mismatch" >&2; exit 67; }
umask 077
mkdir "$output_dir"
psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 --csv -c "SELECT rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolcanlogin,rolreplication,rolbypassrls FROM pg_roles ORDER BY rolname" > "$output_dir/roles.csv"
psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 --csv -c "SELECT parent.rolname AS granted_role,member.rolname AS member_role,grantor.rolname AS grantor,am.admin_option FROM pg_auth_members am JOIN pg_roles parent ON parent.oid=am.roleid JOIN pg_roles member ON member.oid=am.member JOIN pg_roles grantor ON grantor.oid=am.grantor ORDER BY 1,2,3" > "$output_dir/role-memberships.csv"
psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 --csv -c "SELECT table_schema,table_name,grantee,privilege_type,is_grantable FROM information_schema.role_table_grants WHERE table_schema NOT IN ('pg_catalog','information_schema') ORDER BY 1,2,3,4" > "$output_dir/table-grants.csv"
psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 --csv -c "SELECT routine_schema,routine_name,specific_name,grantee,privilege_type,is_grantable FROM information_schema.role_routine_grants WHERE routine_schema NOT IN ('pg_catalog','information_schema') ORDER BY 1,2,3,4,5" > "$output_dir/routine-grants.csv"
psql "$AIFROGI_CATALOG_DATABASE_URL" -X -v ON_ERROR_STOP=1 --csv -c "SELECT n.nspname AS schema_name,c.relname AS object_name,c.relkind,r.rolname AS owner,c.relrowsecurity,c.relforcerowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace JOIN pg_roles r ON r.oid=c.relowner WHERE n.nspname NOT IN ('pg_catalog','information_schema') ORDER BY 1,2" > "$output_dir/object-owners-rls.csv"
(cd "$output_dir" && shasum -a 256 roles.csv role-memberships.csv table-grants.csv routine-grants.csv object-owners-rls.csv > SHA256SUMS)
printf '%s\n' "$output_dir"
